#  My Portfolio Website  

Welcome to my personal portfolio website! This project showcases my skills, projects, and experience as a **Software Engineering Student**.  

##  Features  
- Responsive Design   
- About Me Section 
- Projects Showcase  
- Contact Form  

##  Technologies Used  
- HTML5  
- CSS3  
 



##  How to Use  
1. Clone this repository:  
   ```bash
   git clone https://github.com/Sylvia-Kui/1st-PLP_HACKATHON.git
## Contact me 
   Email: wanguisylvia59@gmail.com
